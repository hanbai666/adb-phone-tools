#!/bin/bash
# nav-bench.sh — 翻页速度基准
#
# 判据是【往返指纹】, 不是"点完截一张看看变没变"。
# 原因: 截图本身要 ~560ms, 你无法区分"等待不够"和"点击丢了";
#       实测那种做法会给出非单调结果(800ms 报失败, 而 150ms 报成功)—— 不可信。
#
#   render : 点 1 次前进 -> 等 wait -> 点 1 次后退 -> 比指纹。
#            能回到原指纹 = 那一次前进确实生效了。与截图快慢无关。
#   burst  : 连点 N 次(间隔 T, 中途不截图) -> 稳定 -> 反向点 N 次 -> 比指纹。
#            回得去 = N 次全部生效; 回不去 = 至少丢了一次。
#
# ⚠ 连点阶段对每一页复用【同一个 y】, 依赖导航按钮纵向容差(实测 ±100px)。
#   若你的 App 容差更小, burst 结果会偏低 —— 那说明"不能复用 y", 而不是"速度上限低"。
#
# 用法: bash nav-bench.sh [--next-x 1162] [--prev-x 277] [--burst 5] [--marker blue]
source "$(dirname "$0")/lib.sh"
need_serial

NX=1162; PX=277; BURST=5; MARKER=blue
while [ $# -gt 0 ]; do
  case "$1" in
    --next-x) NX=$2; shift 2;;
    --prev-x) PX=$2; shift 2;;
    --burst)  BURST=$2; shift 2;;
    --marker) MARKER=$2; shift 2;;
    *) shift;;
  esac
done

ms() { awk -v m="$1" 'BEGIN{printf "%.3f", m/1000}'; }
snap() { shot "$WORK/_nb.png"; pix_fp "$WORK/_nb.png"; }
navy() { shot "$WORK/_nb2.png"; field "$(pix_crop "$WORK/_nb2.png" "$WORK/_nb2c.png" 512)" NAV; }

# 每个试验前必须回到起点指纹, 否则上一轮失败留下的偏移会污染下一轮
# (踩过: 150ms 失败后手机退了一页, 接着 0ms 的试验是在错的基线上做的)
back_to_base() {
  for k in $(seq 1 12); do
    [ "$(snap)" = "$FP0" ] && return 0
    local NY; NY=$(navy); [ -z "$NY" ] && return 1
    tap "$PX" "$NY"; sleep 0.7
  done
  return 1
}

NAVY=$(navy)
[ -z "$NAVY" ] && { echo "取不到导航 y, 放弃"; exit 3; }
echo "=== 起点 ==="
echo "  导航按钮 y=$NAVY (next x=$NX, prev x=$PX)"
FP0=$(snap)
echo "  起点指纹 $FP0"

echo "=== render: 前进 1 次能否被「往返」证实 ==="
for W in 800 500 300 150 0; do
  back_to_base || echo "  (无法回到起点, 结果不可信)" >&2
  tap "$NX" "$NAVY"; sleep "$(ms $W)"
  tap "$PX" "$NAVY"; sleep 0.8
  FP=$(snap)
  if [ "$FP" = "$FP0" ]; then R="往返一致 => 前进生效 ✓"; else R="回不到起点 => 前进没生效(或翻多了) ✗"; fi
  printf '  wait=%-4sms %s\n' "$W" "$R"
done

echo "=== burst: 连点 $BURST 次后能否原路退回 ==="
echo "  (连点阶段复用同一个 y, 所以 $BURST 不能太大 —— 导航 y 每页在变, 超出容差就必然丢)"
for T in 700 400 250 150; do
  back_to_base || echo "  (无法回到起点, 结果不可信)" >&2
  tap "$NX" "$NAVY"; sleep "$(ms $T)"
  for k in $(seq 2 "$BURST"); do tap "$NX" "$NAVY"; sleep "$(ms $T)"; done
  sleep 0.8
  for k in $(seq 1 "$BURST"); do tap "$PX" "$NAVY"; sleep 0.7; done
  sleep 0.8
  FP=$(snap)
  if [ "$FP" = "$FP0" ]; then R="$BURST 次全部生效 ✓"; else R="丢了至少一次 ✗"; fi
  printf '  间隔 %-4sms %s\n' "$T" "$R"
done

echo
echo "解读: 找到【最大且仍 ✓】的间隔, 就是可用的最快连点速度。"
echo "参考(某作业 App 1440x3168, 用「数页数」的严格判据): 700ms 96 连击零失误; 400ms 3/3; 250ms 2/3 开始丢。"
