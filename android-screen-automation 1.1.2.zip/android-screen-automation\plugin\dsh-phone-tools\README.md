# dsh-phone-tools

把 `android-screen-automation` skill 的脚本挂成 DSH **常驻工具**（6 个）。

## 为什么存在

skill 的可用性押在 `description` 上——模型得先"想起"它才会去读 SKILL.md。
description 一旦被 YAML 引号截断，skill 会在新会话里**静默消失且不报错**（实测踩过）。
插件的工具直接出现在每一轮对话的工具表里，不需要任何触发。

**这不是第二份实现**：几何/点击/答案比对逻辑仍然只有一份，在
`C:\Users\54385\.dsh\skills\android-screen-automation\scripts\`。
本插件只做三件事：解析路径 → 起 bash → 把脚本的 stdout/stderr 原样递回来。

## 工具

| 工具 | 对应脚本 | 作用 |
|---|---|---|
| `phone_probe` | `env-probe.sh` | 设备/屏幕/唤醒/前台 App/可访问性树 + **该走哪条路线**的判定 + 实测两条读屏通道耗时 |
| `phone_gate` | `tap-probe.sh` | **动手前的闸门**：证明按坐标点击真能生效，并标定该点哪一列 x |
| `phone_read` | `shot` + `pix_crop` + `pix_opts` | 截当前屏 → 自适应裁剪到约 512px（约 1 视觉 tile）→ 输出选项 y、选中态、导航 y、**像素↔设备坐标换算公式** |
| `phone_tap` | `input tap` | 唯一执行原语。坐标必须来自 `phone_read` 或 index.txt，**绝不能猜固定 y** |
| `phone_collect` | `collect-run.sh` | 采集遍：逐页截图+裁剪+记坐标，只翻页不点选项 |
| `phone_answer` | `answer-run.sh` | 作答遍：自校正比对，只点需要改的 |

## 刻意的设计

- **全部工具 `isConcurrencySafe: () => false`**。手机是单资源，并发点屏会互相踩，
  是这套流程里最容易毁卷的坏法。
- **`phone_read` 的选项检测跑在原分辨率截图上**，不在缩放图上——
  在缩放图上检测会因为标记像素几何变化而漏检（采集遍曾经因此输出空 `opts=[]`）。
- **降级不消失**：skill 脚本缺失时，插件仍注册一个只回报"缺什么、怎么修"的诊断工具，
  而不是让 6 个工具整体消失、宿主只回一句 failed to import。

## 安装

```bash
dsh plugin --profile desktop add link:<本目录绝对路径>
```

或在 DSH 会话里：

```
plugin_manager(action="install_bundle", target="link:<本目录绝对路径>")
```

装完**要重载/重启 DSH** 才生效——当前那个对话看不到新工具（和 skill 一样）。

## 配置（可选）

在 profile 的该行 `config` 里给：

```yaml
- id: dsh-phone-tools
  name: 'dsh-phone-tools'
  config:
    skillDir: 'C:\Users\54385\.dsh\skills\android-screen-automation'
    serial: '10AG632J1U0088A'
    adb: 'C:\adb\platform-tools\adb.exe'
    workDir: 'C:\Users\54385\.dsh\dsh_orb\.phone'
```

默认值即上表内容；只有换手机/换路径时才需要配。

## 版本

1.0.0 —— 首版，6 工具。逻辑对应 skill 的 8 个脚本（含 `nav-bench.sh`、`start.sh` 未包装，
仍按 SKILL.md 直接跑）。
