#!/bin/bash
# collect-run.sh — 采集遍: 逐页截图+自适应裁剪+记录坐标, 并翻页
#
# 产物(默认在 $WORK/collect/):
#   p001.png ...     每页的裁剪图(给我读的, 1 tile 左右)
#   index.txt        每行: <页号> | <选项y列表> | <导航y>
#   answers.txt      每页检测到的选中态(快照, 供比对)
#
# 用法: bash collect-run.sh --pages 38 --next-x 1162 --prev-x 277 \
#                           --marker blue --settle 400 [--dir outdir] [--backward]
source "$(dirname "$0")/lib.sh"
need_serial

PAGES=38; NX=1162; PX=277; MARKER=blue; SETTLE=400; DIR="$WORK/collect"; BACK=0
while [ $# -gt 0 ]; do
  case "$1" in
    --pages) PAGES=$2; shift 2;;
    --next-x) NX=$2; shift 2;;
    --prev-x) PX=$2; shift 2;;
    --marker) MARKER=$2; shift 2;;
    --settle) SETTLE=$2; shift 2;;
    --dir) DIR=$2; shift 2;;
    --backward) BACK=1; shift 1;;
    *) shift;;
  esac
done
mkdir -p "$DIR"
IDX="$DIR/index.txt"; : > "$IDX"

for i in $(seq 1 "$PAGES"); do
  N=$(printf '%03d' "$i")
  shot "$WORK/_c.png"
  COUT=$(pix_crop "$WORK/_c.png" "$DIR/p$N.png" 512)
  NAVY=$(field "$COUT" NAV)
  # 选项检测必须在【原始全分辨率截图】上做:
  # 裁剪图被缩放过, 标记的像素几何变了, minh/宽高比阈值会失配 -> 检测为空。
  # 同时把 crop 报出的 NAV y 传进去, 排除底部导航文字(否则会多出一个假选项 E)。
  OOUT=$(pix_opts "$WORK/_c.png" --marker "$MARKER" --nav-y "$NAVY")
  YS=$(field "$OOUT" OPTS | tr -d '\n' | sed 's/ *$//')
  SEL=$(field "$OOUT" SEL | tr -d '\n' | sed 's/ *$//')
  if [ "$BACK" -eq 1 ]; then X=$PX; else X=$NX; fi
  echo "$i | $YS | $NAVY | $SEL" >> "$IDX"
  printf '  [%3d/%3d] opts=[%s] sel=[%s] nav=%s\n' "$i" "$PAGES" "$YS" "$SEL" "$NAVY"
  [ -z "${YS// /}" ] && echo "     !! 本页没检测到任何选项标记 —— 别继续, 先查 marker/--x0/--minh" >&2
  if [ "$i" -lt "$PAGES" ]; then
    tap "$X" "$NAVY"
    sleep "$(awk -v m="$SETTLE" 'BEGIN{printf "%.3f", m/1000}')"
  fi
done
echo "采集完成: $PAGES 页 -> $DIR"
echo "  index.txt 行数: $(wc -l < "$IDX")"
echo "  下一步: 读 p*.png 产出 key.txt(每行: <页号> <字母,多选逗号分隔>), 再跑 answer-run.sh"
