#!/bin/bash
# start.sh — 入口 / 模式闸门
#
# 运行前先问清一件事: 这次是"复用已有答案键"还是"从零遍历截图再思考"。
# 两条路的代价差一个数量级, 选错了要么白花钱、要么拿到错键。
#
# 用法:
#   bash start.sh                          # 交互式询问
#   bash start.sh --mode key               # 非交互: 复用答案键
#   bash start.sh --mode fresh             # 非交互: 从零开始
#   bash start.sh --mode key --probe       # 顺便把阶段0(环境监测)也跑了
#   bash start.sh --mode key --pages 196 --serial <SERIAL>
source "$(dirname "$0")/lib.sh"
SD="$(cd "$(dirname "$0")" && pwd)"   # 打印命令时用绝对路径, 免得依赖 cwd

MODE=""; PROBE=0; PAGES=196
while [ $# -gt 0 ]; do
  case "$1" in
    --mode) MODE=$2; shift 2;;
    --probe) PROBE=1; shift 1;;
    --pages) PAGES=$2; shift 2;;
    --serial) SERIAL=$2; shift 2;;
    *) shift;;
  esac
done

cat <<'BANNER'
===============================================================
 Android 屏幕自动化 —— 开跑前先定模式
===============================================================
  [1] key    复用已有答案键 (key.txt)
             跳过"读题判断题"这一步 —— 省约 33k token 和大量时间。
             ⚠ 前提: 卷面题目与顺序和 key.txt 完全一致。
               题号错位的话, 作答遍照样报"成功", 但整卷是错的。
             ⚠ 仍然要跑一遍 collect 采集导航坐标(截图+检测, 约 12 分钟/196 页),
               因为"下一题按钮的纵坐标"每页都在变, 必须实测。

  [2] fresh  从零开始: 遍历截图 -> 思考出答案键 -> 倒序作答
             慢, 但在任何一份新卷子上都成立, 不依赖任何已有假设。
             采集遍的截图同时也就是要读的题面, 一次采集两用。

  ⚠ 两条路都: 答案键的正确性只能靠人工/官方答案核对 ——
     自校正只保证"手机状态 == 你的键", 不保证"你的键是对的"。
===============================================================
BANNER

if [ -z "$MODE" ]; then
  printf "请选择模式 [1/2] (默认 1): "
  read -r ANS
  case "$ANS" in
    2|fresh|f|F) MODE=fresh;;
    *)           MODE=key;;
  esac
fi
case "$MODE" in
  key|fresh) ;;
  *) echo "模式只能是 key 或 fresh"; exit 1;;
esac

mkdir -p "$WORK"
echo "$MODE" > "$WORK/mode.txt"
echo
echo ">>> 已选模式: $MODE   (记录在 $WORK/mode.txt)"
echo

S="${SERIAL:-\$SERIAL}"
echo "请按顺序执行:"
echo
echo "  # 阶段0 环境监测(设备/屏幕/唤醒/前台App/耗时/节点数/路线判定)"
echo "  bash $SD/env-probe.sh --serial $S"
echo "  # 阶段1 选项点击尝试(找出该点哪一列 x, 输出 TAPX)"
echo "  bash $SD/tap-probe.sh --serial $S --marker blue"
echo "  # 阶段2 采集遍(逐页截图 + 记录每题选项纵坐标与翻页纵坐标)"
echo "  bash $SD/collect-run.sh --serial $S --dir $WORK --pages $PAGES --marker blue"
echo

if [ "$MODE" = "fresh" ]; then
  cat <<EOF
  # 阶段3 【模型来做】逐页看 $WORK/q*.png, 产出 $WORK/key.txt
  #        格式: 每行 "<题号> <字母>"; 多选题写成 "<题号> ACD"
  #
  # 阶段4 作答遍 —— 倒序(推荐): 采集遍结束时就停在最后一页,
  #        倒着答可以直接开跑, 省掉"退回第1题"的整卷导航。
  bash $SD/answer-run.sh --serial $S --dir $WORK --key $WORK/key.txt \\
       --from $PAGES --to 1 --backward --marker blue --tapx <上一步的TAPX>
EOF
else
  cat <<EOF
  # 阶段3 复用键: 把已有 key.txt 放到 $WORK/key.txt
  #        ⚠ 先人工核验题号对齐: 采集下来的第1页和最后一页, 题面要和键的首尾对得上。
  #
  # 阶段4 作答遍 —— 倒序(推荐, 同样省掉退回第1题的导航)
  bash $SD/answer-run.sh --serial $S --dir $WORK --key $WORK/key.txt \\
       --from $PAGES --to 1 --backward --marker blue --tapx <上一步的TAPX>
  #        若手机此刻不在第 $PAGES 页, 改成: --from 1 --to $PAGES (去掉 --backward)
  #        作答遍是幂等的: 再跑一遍应报 "修正 0" —— 那是收敛的证明, 也顺便验证了对齐。
EOF
fi

echo
if [ "$PROBE" -eq 1 ]; then
  echo ">>> 顺带执行阶段0 ..."
  ADB="$ADB" PY="$PY" bash "$(dirname "$0")/env-probe.sh" ${SERIAL:+--serial "$SERIAL"}
else
  echo "提示: 加 --probe 可在选完模式后立刻跑阶段0。"
fi
