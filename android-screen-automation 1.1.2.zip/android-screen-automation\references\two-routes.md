# 两条读取路线：先判定，再动手

拿到一个新 App，**第一件事是判定走哪条路线**。判错了后面全白做。

## 判定命令

```bash
adb shell 'dumpsys window 2>/dev/null | grep mCurrentFocus'        # 前台是谁
adb shell 'uiautomator dump /sdcard/u.xml >/dev/null 2>&1;
            grep -o "<node" /sdcard/u.xml | wc -l'                 # 节点数
adb shell 'grep -o "text=\"[^\"]\{1,\}\"" /sdcard/u.xml | head'    # 有没有可用文本
adb shell 'cat /proc/net/unix | grep -o "webview_devtools_remote[^ ]*"'  # 有没有 DevTools
```

| 观测 | 结论 |
|---|---|
| 节点数 = 1 且无文本 | 纯 Canvas / 未暴露 → **路线 A（截图 + 视觉）** |
| 节点多、题干/选项是独立节点且带 bounds | **路线 B（可访问性树）** |
| 有 `webview_devtools_remote` | **路线 C（DevTools 直读 DOM）**，最优，但很少见 |

**必须多探 2-3 次**：树的暴露是惰性且会丢的。同一个页面可能这次齐全、下次只剩外壳
（实测同一 App 同一页：52 节点 ↔ 29 节点）。拿不到就按 A 走，不要卡在 B。

---

## 路线 A：截图 + 视觉（最通用）

**适用**：微信小程序、Canvas 渲染、树里没有内容的 H5。

**链路**：`screencap` → 自适应裁剪 → **模型读图** → 按图上位置算设备坐标 → `input tap`

```bash
source scripts/lib.sh; need_serial
shot "$WORK/a.png"
pix.py crop "$WORK/a.png" "$WORK/a_c.png" 512     # 输出 READ/MAP 行: 图上坐标 -> 设备坐标
#   READ 48 451 1354 1931 0.3459 -> 451x512
#   MAP device_x = 48 + px/0.3459 ; device_y = 451 + py/0.3459
```

关键点：
- **裁剪必须自适应**（自动框出内容再去空白）：既保证清晰，又把图压进 512×512 的
  "1 tile" 区间。196 题从 ~157k token 压到 ~33k —— **这是能不能跑完的前提，不是优化**。
- 点击坐标 = `图上读到的像素 / scale + 原点`，不要凭印象写固定坐标。
- 核验手段：再截一张图，看选中态是否改变。

**加速（实测有效的顺序）**
1. 坐标在采集遍里逐页存进 `index.txt` → 作业遍**免截图免检测**，每题只剩 2 次点击
2. 点击用 `batch_taps` 在**一次 adb shell** 里连发，省掉每次约 60ms 往返
3. 翻页间隔压到 **400ms**（实测下限；250ms 开始丢）

---

## 路线 B：可访问性树（有树时最快最准）

**适用**：原生控件应用、部分 H5（题干/选项作为独立节点暴露）。

**链路**：`uiautomator dump` → 解析 XML → 按文本/ bounds 定位 → `input tap`（或按节点点击）

```bash
adb shell 'uiautomator dump /sdcard/u.xml'; adb pull /sdcard/u.xml u.xml
```

要点：
- **节点文本常带前导/尾随空格**（`'下一题 '`）→ 匹配用 `-match`，别用 `-eq`
- 选项节点常 `clickable=false` → 仍要按 **bounds 中心**点
- **选择状态通常可机读**（选中后节点文本会追加"已选择"，或有 `checked` 属性）→
  **核验不需要视觉**，这是路线 B 最大的优势
- 导航节点文本同样带空格陷阱；`bounds` 每次都是实时值，**没有漂移风险**

---

## 为什么不用"盲点固定坐标"

路线 A 里最容易走偏的是"一次性标定好坐标然后整卷盲点"。实测教训：

- 版式会随内容变（题干行数不同 → 导航按钮 y 在 1399~2313 之间浮动）
- 一旦某个假设失效（漏检一个元素），盲点会把**后续每一页都点错**
- 而且**不报错**

所以：**要么每题重新取坐标，要么把坐标在采集遍里逐页存下来**（前者慢、后者快且安全）。
纯盲点只在"页面模板固定且已验证"时才用。
