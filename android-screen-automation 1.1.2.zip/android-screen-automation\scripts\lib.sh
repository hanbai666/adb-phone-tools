#!/bin/bash
# lib.sh — 手机自动化公共库。被其它脚本 source。
# 约定: 所有脚本都在 bash 下运行; 需要 adb 在 PATH 或 ADB 环境变量里。
set -u

ADB="${ADB:-adb}"
[ -x "C:/adb/platform-tools/adb.exe" ] && [ "$ADB" = "adb" ] && ADB="C:/adb/platform-tools/adb.exe"

# Python: 必须【真能 import PIL】才算可用。
# 踩过的坑: Windows 上 `command -v python` 会命中 Microsoft Store 的占位 stub,
# 它存在、可执行, 但一跑就打印 "Python was not found" —— 只测存在性会被骗过去。
PY="${PY:-}"
_py_ok() { [ -n "${1:-}" ] && "$1" -c 'import PIL' >/dev/null 2>&1; }
if ! _py_ok "$PY"; then
  PY=""
  for cand in python3 python \
      "C:/Users/54385/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/python.exe"; do
    if _py_ok "$cand"; then PY="$cand"; break; fi
  done
fi
if ! _py_ok "$PY"; then
  echo "FATAL: 找不到可用的 python(且需装 Pillow)。用 PY=/path/to/python 指定。" >&2
  exit 2
fi
echo "PY=$PY" >&2

# 让【所有】脚本都能用 --serial <SERIAL> 指定设备。
# 踩过的坑: 各脚本自己解析参数, 有的有 --serial 有的没有; 没有的那个会
# 静默忽略这个参数然后自动挑第一台设备 —— 多设备时就会操作错手机。
# 这里在参数解析之前统一扫一遍, 从根上消除这个不一致。
_prev=""
for _a in "$@"; do
  if [ "$_prev" = "--serial" ]; then SER="$_a"; export SER; break; fi
  _prev="$_a"
done

WORK="${WORK:-$(pwd)/.phone}"
mkdir -p "$WORK"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIX="$SCRIPT_DIR/pix.py"

# ---------- 设备 ----------
# 选一台真实设备: 排除 offline 与 emulator-*
resolve_serial() {
  if [ -n "${SER:-}" ]; then echo "$SER"; return; fi
  "$ADB" devices | awk '/\tdevice$/ && $1 !~ /^emulator-/{print $1; exit}'
}

need_serial() {
  SER="$(resolve_serial)"
  if [ -z "$SER" ]; then
    echo "FATAL: 没有可用设备。先确认: 数据线/无线调试已连, 且 adb devices 里出现 device 状态。" >&2
    echo "  当前 adb devices 输出:" >&2
    "$ADB" devices >&2
    exit 2
  fi
  export SER
}

# ---------- 原子操作 ----------
sh_() { "$ADB" -s "$SER" shell "$1" 2>/dev/null; }

shot() {  # shot <输出png>
  "$ADB" -s "$SER" exec-out screencap -p > "$1"
  [ -s "$1" ] || { echo "FATAL: 截图失败(0 字节) -> $1" >&2; return 1; }
}

tap() { "$ADB" -s "$SER" shell "input tap $1 $2" >/dev/null 2>&1; }

# 一次 adb shell 里批量发点击, 用 ';' 串起来。比逐次调用省掉每次约 60ms 往返。
# 用法: batch_taps "1162 2055 400" "250 1274 0" ...   参数: "x y 之后等待ms"
batch_taps() {
  local cmd=""
  local spec x y w
  for spec in "$@"; do
    set -- $spec
    x=$1; y=$2; w=${3:-0}
    cmd="$cmd input tap $x $y;"
    [ "$w" -gt 0 ] && cmd="$cmd sleep $(awk -v m="$w" 'BEGIN{printf "%.3f", m/1000}');"
  done
  sh_ "$cmd"
}

# ---------- 分析封装 ----------
pix_crop() { "$PY" "$PIX" crop "$1" "$2" "${3:-512}" "${@:4}"; }
pix_opts() { "$PY" "$PIX" opts "$1" "${@:2}"; }
pix_fp()   { "$PY" "$PIX" fp "$1" "${@:2}"; }

# 从 pix.py 输出里取字段
field() {  # field <文本> <键>  例如 field "$OUT" NAV -> 取 ycenter 值
  printf '%s\n' "$1" | awk -v k="$2" '
    /^OPTS/ && k=="OPTS" { for(i=2;i<=NF;i++) if($i ~ /^[A-H]=[0-9]+$/){split($i,a,"=");printf "%s ",a[2]} ; print "" }
    /^SEL/  && k=="SEL"  { for(i=2;i<=NF;i++) if($i ~ /^[A-H]=[01]$/){split($i,a,"=");printf "%s ",a[2]} ; print "" }
    /^NAV/  && k=="NAV"  { for(i=1;i<=NF;i++) if($i ~ /^ycenter=/){split($i,a,"=");print a[2]} }
    /^READ/ && k=="READ" { print }
    /^MAP/  && k=="MAP"  { print }
  '
}
