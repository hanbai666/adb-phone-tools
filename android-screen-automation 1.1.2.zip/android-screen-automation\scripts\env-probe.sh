#!/bin/bash
# env-probe.sh — 阶段0: 手机环境监测 + 路线判定
# 输出一份紧凑报告: 设备/屏幕/前台App/可访问性树/两条路线该走哪条/各项耗时
# 用法: bash env-probe.sh [--json]
source "$(dirname "$0")/lib.sh"

need_serial
echo "=== 设备 ==="
"$ADB" devices | sed 's/^/  /'
echo "  SERIAL=$SER"

echo "=== 屏幕 ==="
echo "  $(sh_ 'wm size' | tr -d '\r' | tr '\n' ' ')"
echo "  $(sh_ 'wm density' | tr -d '\r' | tr '\n' ' ')"
WAKE=$(sh_ 'dumpsys power | grep -m1 mWakefulness= | tr -d "\r"')
echo "  ${WAKE:-mWakefulness=?}"
# 息屏时 uiautomator dump 与截图都可能拿到锁屏/空白 —— 先点亮再探测
case "$WAKE" in
  *Asleep*|*Dozing*)
    echo "  -> 屏幕未唤醒, 发 keyevent 224 点亮并等待"
    sh_ 'input keyevent 224' >/dev/null
    sleep 2
    WAKE=$(sh_ 'dumpsys power | grep -m1 mWakefulness= | tr -d "\r"')
    echo "  ${WAKE:-mWakefulness=?} (点亮后)"
    ;;
esac

echo "=== 前台 App ==="
FOCUS=$(sh_ 'dumpsys window 2>/dev/null | grep mCurrentFocus | tail -1 | tr -d "\r"')
echo "  ${FOCUS:-未取到}"

echo "=== 耗时基准 ==="
T0=$(date +%s%N); shot "$WORK/_e.png"; T1=$(date +%s%N)
echo "  screencap(全屏)      : $(( (T1-T0)/1000000 )) ms"
T0=$(date +%s%N); sh_ 'uiautomator dump /sdcard/__probe.xml' >/dev/null; T1=$(date +%s%N)
echo "  uiautomator dump     : $(( (T1-T0)/1000000 )) ms"
T0=$(date +%s%N); tap 720 60; T1=$(date +%s%N)   # 点状态栏区域测往返, 不会误触内容
echo "  input tap 往返       : $(( (T1-T0)/1000000 )) ms"

echo "=== 可访问性树 (决定走哪条路线) ==="
# 树是惰性的: 连试几次。注意区分【dump 失败】与【dump 成功但没有文本】——
# 前者不能当作"没有可访问性内容"来判定路线, 否则会误判成 A 路线。
DUMP_OK=0
for try in 1 2 3; do
  sh_ 'uiautomator dump /sdcard/__probe.xml' >/dev/null 2>&1
  if "$ADB" -s "$SER" pull /sdcard/__probe.xml "$WORK/_probe.xml" >/dev/null 2>&1 && [ -s "$WORK/_probe.xml" ]; then
    DUMP_OK=1; break
  fi
  sleep 1
done
if [ "$DUMP_OK" = "1" ]; then
  NODES=$(tr '<' '\n' < "$WORK/_probe.xml" | grep -c '^node')
  TEXTS=$(tr '<' '\n' < "$WORK/_probe.xml" | grep '^node' | sed -n 's/.*text="\([^"]*\)".*/\1/p' | grep -c .)
  echo "  节点数=$NODES  非空文本节点=$TEXTS  (第 $try 次成功)"
else
  NODES=0; TEXTS=0
  echo "  !! uiautomator dump 连续 3 次失败 —— 这【不代表】页面上没有内容。"
  echo "     常见原因: 屏幕锁着 / uiautomator 服务被占用 / 系统限制。"
  echo "     先解锁重试; 仍失败就按 A 路线(截图)走。"
fi
DEVTOOLS=$(sh_ 'cat /proc/net/unix 2>/dev/null | grep -o "webview_devtools_remote[^ ]*" | sort -u' | tr -d '\r')
if [ -n "$DEVTOOLS" ]; then
  echo "  WebView DevTools socket: 有 -> 可直读 DOM(最优路线)"
else
  echo "  WebView DevTools socket: 无"
fi

echo "=== 路线判定 ==="
if [ "$DUMP_OK" != "1" ]; then
  echo "  => 无法判定(dump 失败), 建议先按【方案A(截图+视觉)】走"
elif [ "${TEXTS:-0}" -ge 3 ]; then
  echo "  => 方案B(可访问性树): 页面文本可直接读, 点击可用 nodes 的 bounds"
  echo "     先读 references/two-routes.md 的 B 路线"
else
  echo "  => 方案A(截图+视觉): 树可读但没有可用文本(纯 Canvas/WebView 未暴露)"
  echo "     先读 references/two-routes.md 的 A 路线"
fi
echo "  注意: 树的暴露是【惰性且会丢】的 —— 同一页面可能这次有、下次没有。"
echo "        判定前多探 2-3 次; 拿不到就按 A 路线走, 不要卡在 B。"
echo
echo "=== 下一步 ==="
echo "  bash $(dirname "$0")/tap-probe.sh     # 选项点击尝试 + 标定点击列"
