#!/usr/bin/env python3
"""pix.py — Android 截图分析工具（无 OCR，纯像素）

子命令:
  crop <in.png> <out.png> [maxside]      自适应裁剪: 自动框出内容(去掉大片空白), 缩到 maxside 以内(默认512)
                                         打印 READ x0 y0 x1 y1 scale   -> 设备坐标 = (x0+px/scale, y0+py/scale)
                                              NAV  ycenter               -> 底部导航行中心的设备 y
  opts <in.png> [--x0 N] [--x1 N] [--marker blue|dark]
                                         检测选项标记(圈/盘)的行坐标与选中状态
                                         打印 OPTS A=<y> B=<y> ...  和 SEL A=0|1 ...
  fp   <in.png> [x0 y0 x1 y1]            区域指纹(md5), 用于判断"页面是否变了"
  red  <in.png>                          找红色高亮圆点(例如题号条当前题) -> 打印 RED x y

设计要点(踩过的坑):
  * 选中态不能用"圆心取色"判断 —— 实心盘中心是白色字母, 会误判为未选。
    必须用【外接框内标记色像素的面积占比】: 实心盘约 0.5-0.6, 空心环约 0.15。
  * 标记高度是区分"选项"与"正文文字"的关键, 用 --minh/--maxh 卡住。
"""
import sys, hashlib
from PIL import Image

def parse_args(argv):
    args, flags = [], {}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a.startswith('--'):
            k = a[2:]
            v = argv[i + 1] if i + 1 < len(argv) else '1'
            flags[k] = v
            i += 2
        else:
            args.append(a)
            i += 1
    return args, flags

def is_marker(p, kind):
    r, g, b = p[0], p[1], p[2]
    if kind == 'blue':
        return (b - r) > 40 and b > 120 and g > 60
    # dark: 深色笔画
    return (0.299 * r + 0.587 * g + 0.114 * b) < 140

def cmd_crop(args, flags):
    src, dst = args[1], args[2]
    maxside = int(args[3]) if len(args) > 3 else 512
    im = Image.open(src).convert('L')
    W, H = im.size
    px = im.load()
    top = int(flags.get('top', int(H * 0.11)))       # 默认跳过状态栏+标题栏
    bot = int(flags.get('bot', int(H * 0.977)))      # 默认跳过系统导航栏
    thr = int(flags.get('thr', 200))
    step = int(flags.get('step', 4))

    def rowdark(y):
        c = 0
        for x in range(0, W, step):
            if px[x, y] < thr:
                c += 1
        return c

    rows = [rowdark(y) for y in range(top, bot)]
    cont = [i for i, v in enumerate(rows) if v > 2]
    if not cont:
        print('EMPTY')
        return
    y0, y1 = top + cont[0], top + cont[-1]

    # 找最后一个大空白间隙 -> 其后是导航行
    gap = int(flags.get('gap', 60))
    nav_top, run, last = y1 + 1, 0, None
    for i, v in enumerate(rows):
        if v <= 2:
            run += 1
        else:
            if run >= gap:
                last = (top + i - run, top + i)
            run = 0
    if last:
        nav_top = last[1]
    if nav_top >= y1 - 40:
        nav_top = y1 + 1
    ry1 = nav_top - 12
    if ry1 <= y0 + 40:
        ry1 = y1

    def coldark(x):
        c = 0
        for y in range(y0, ry1, step):
            if px[x, y] < thr:
                c += 1
        return c
    cols = [x for x in range(0, W, step) if coldark(x) > 0]
    x0 = max(0, cols[0] - 12) if cols else 0
    x1 = min(W, cols[-1] + 14) if cols else W

    rgb = Image.open(src).convert('RGB')
    crop = rgb.crop((x0, y0, x1, ry1))
    w, h = crop.size
    scale = min(maxside / w, maxside / h, 1.0)
    if scale < 1.0:
        crop = crop.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.LANCZOS)
    crop.save(dst)
    navy = int((nav_top + y1) / 2) if nav_top <= y1 else y1
    print('READ %d %d %d %d %.4f -> %dx%d' % (x0, y0, x1, ry1, scale, crop.size[0], crop.size[1]))
    print('NAV ycenter=%d' % navy)
    print('MAP device_x = %d + px/%.4f ; device_y = %d + py/%.4f' % (x0, scale, y0, scale))

def cmd_opts(args, flags):
    src = args[1]
    kind = flags.get('marker', 'blue')
    rgb = Image.open(src).convert('RGB')
    W, H = rgb.size
    px = rgb.load()
    x0 = int(flags.get('x0', 40))
    x1 = int(flags.get('x1', min(W, 480)))
    minh = int(flags.get('minh', 30))
    ytop = int(flags.get('top', int(H * 0.11)))
    ybot = int(flags.get('bot', int(H * 0.90)))
    step = int(flags.get('step', 3))

    rows = []
    for y in range(ytop, ybot):
        c = 0
        for x in range(x0, x1, step):
            if is_marker(px[x, y], kind):
                c += 1
        rows.append(c)

    clusters, start = [], None
    for i, c in enumerate(rows):
        if c >= 2 and start is None:
            start = i
        elif c < 2 and start is not None:
            clusters.append((ytop + start, ytop + i - 1))
            start = None
    if start is not None:
        clusters.append((ytop + start, ytop + len(rows) - 1))
    clusters = [c for c in clusters if (c[1] - c[0] + 1) >= minh]

    letters = 'ABCDEFGH'
    det, sel = [], []
    # 形状过滤: 区分"选项标记"和"底部导航的文字"。
    # 实测(1440 宽): 选项圈 bw/height ≈ 2.8-2.9(空心) 或 ≈1.0(实心);
    #                导航行"上一题"文字 ≈ 3.9 -> 用 3.3 卡掉。
    # 更稳的做法是由调用方把 crop 报出的 NAV y 用 --nav-y 传进来, 直接排除那一条带。
    maxratio = float(flags.get('maxratio', 3.3))
    minw = int(flags.get('minw', 24))
    navy = int(flags['nav-y']) if 'nav-y' in flags else None
    for (a, b) in clusters:
        if navy is not None and abs((a + b) / 2 - navy) <= 120:
            continue
        xs, cnt = [], 0
        for yy in range(a, b + 1):
            for x in range(x0, x1):
                if is_marker(px[x, yy], kind):
                    cnt += 1
                    xs.append(x)
        if not xs:
            continue
        bw = max(xs) - min(xs) + 1
        bh = b - a + 1
        if bw < minw or bw > maxratio * bh:
            continue
        L = letters[len(det)] if len(det) < len(letters) else '?'
        det.append('%s=%d' % (L, int((a + b) / 2)))
        sel.append('%s=%d' % (L, 1 if (cnt / float(bw * bh)) >= 0.35 else 0))
    print('OPTS ' + ' '.join(det))
    print('SEL ' + ' '.join(sel))

def cmd_fp(args, flags):
    src = args[1]
    im = Image.open(src).convert('L')
    W, H = im.size
    box = (0, int(H * 0.12), W, int(H * 0.80))
    if len(args) >= 6:
        box = (int(args[2]), int(args[3]), int(args[4]), int(args[5]))
    print(hashlib.md5(im.crop(box).tobytes()).hexdigest())

def cmd_red(args, flags):
    src = args[1]
    rgb = Image.open(src).convert('RGB')
    W, H = rgb.size
    px = rgb.load()
    ytop, ybot = int(H * 0.08), int(H * 0.16)
    xs, ys = [], []
    for y in range(ytop, ybot, 2):
        for x in range(0, W, 2):
            r, g, b = px[x, y]
            if r > 180 and g < 110 and b < 110:
                xs.append(x)
                ys.append(y)
    if xs:
        print('RED %d %d' % (sum(xs) // len(xs), sum(ys) // len(ys)))
    else:
        print('RED none')

if __name__ == '__main__':
    args, flags = parse_args(sys.argv[1:])
    if not args:
        print(__doc__)
        sys.exit(1)
    {'crop': cmd_crop, 'opts': cmd_opts, 'fp': cmd_fp, 'red': cmd_red}[args[0]](args, flags)
