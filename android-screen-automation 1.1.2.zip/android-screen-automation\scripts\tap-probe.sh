#!/bin/bash
# tap-probe.sh — 阶段1: 选项点击尝试 + 标定点击列
#
# 目的: 动手批量操作之前, 先证明"按坐标点击真的能生效", 并找出该点哪一列 x。
# 这是整套流程里最容易跳过、也最容易翻车的一步:
#   - 手势导航会吃掉屏幕底部约 150px(画得出来, 点不到)
#   - 选项"标记圈的中心"未必是可点击点
#   - 不同 App 的可点击列不同(实测微信小程序 x=250; 某作业 App 标记在 x≈100, 点击列也在 250)
#
# 做法: 检测标记 -> 挑一个【当前未选中】的选项 -> 试若干列各点一次 -> 看选中态是否翻转 -> 复原
# 用法: bash tap-probe.sh [--marker blue|dark] [--tapx "250 200 320"] [--opt C]
source "$(dirname "$0")/lib.sh"
need_serial

MARKER=blue; TAPX=""; OPT=""
while [ $# -gt 0 ]; do
  case "$1" in
    --marker) MARKER=$2; shift 2;;
    --tapx)   TAPX=$2; shift 2;;
    --opt)    OPT=$2; shift 2;;
    *) shift;;
  esac
done

detect() {   # detect <png> -> 输出 "y1 y2 ..." 与 "s1 s2 ..."
  local O
  O=$(pix_opts "$1" --marker "$MARKER")
  YS=$(field "$O" OPTS); SELS=$(field "$O" SEL)
}

echo "=== 1) 检测选项标记 (marker=$MARKER) ==="
shot "$WORK/_t0.png"
detect "$WORK/_t0.png"
SELS_ORIG="$SELS"     # 必须留底 —— 复原要靠它(踩过: 忘了赋值 -> set -u 报错 -> 复原整段没跑, 现场被改)
[ -z "${YS// /}" ] && {
  echo "  没有检测到标记。调整 pix.py opts 的参数:"
  echo "    --marker blue|dark   标记是蓝色圈/盘, 还是深色圈"
  echo "    --x0/--x1            标记所在横条(默认 40-480)"
  echo "    --minh               标记最小高度(滤掉正文文字, 关键参数)"
  exit 1
}
N=$(echo $YS | wc -w)
echo "  检测到 $N 个标记: y=[$YS]"
echo "  当前选中态: [$SELS]"

# 挑一个未选中的选项做试验
TARGET_IDX=""
for k in $(seq 1 "$N"); do
  S=$(echo $SELS | awk -v n="$k" '{print $n}')
  if [ -z "$OPT" ]; then
    [ "$S" = "0" ] && { TARGET_IDX=$k; break; }
  else
    W=$(( $(printf '%s' "$OPT" | od -An -tu1 | awk '{print $1}') - 64 ))
    [ "$k" = "$W" ] && { TARGET_IDX=$k; break; }
  fi
done
[ -z "$TARGET_IDX" ] && { echo "  所有选项都已选中 —— 请先手动取消一个, 或用 --opt 指定另一个未选项"; exit 1; }
TARGET_L=$(echo "ABCDEFGH" | cut -c"$TARGET_IDX")
TY=$(echo $YS | awk -v n="$TARGET_IDX" '{print $n}')
echo "=== 2) 点击尝试: 目标 $TARGET_L (y=$TY), 点击前未选中 ==="

if [ -n "$TAPX" ]; then CAND="$TAPX"; else CAND="250 200 320 150 400"; fi
WON=""
for X in $CAND; do
  tap "$X" "$TY"; sleep 0.7
  shot "$WORK/_t1.png"
  detect "$WORK/_t1.png"
  S2=$(echo $SELS | awk -v n="$TARGET_IDX" '{print $n}')
  echo "  tapx=$X -> $TARGET_L 的选中态: ${S2:-?} (期望 1)"
  if [ "${S2:-0}" = "1" ]; then WON=$X; echo "  ✓ 生效列 = $X"; break; fi
done

if [ -z "$WON" ]; then
  echo "  ✗ 所有候选列都没生效。逐个排查:"
  echo "    - 屏幕真的亮着吗(dumpsys power | grep mWakefulness)"
  echo "    - y=$TY 是否落在底部【手势导航禁区】(画得出点不到)。换更靠上的元素试"
  echo "    - 标记中心不是可点击点: 试点标记右侧的文字区(把候选列往右挪)"
  echo "    - App 是否有遮罩/引导层挡着"
  exit 3
fi

echo "=== 3) 复原现场 ==="
# 若是单选(radio): 点回原来的选中项即可; 若原本无选中项, 再点一次目标(复选可取消)
OTHER=""
for k in $(seq 1 "$N"); do
  S0=$(echo "$SELS_ORIG" | awk -v n="$k" '{print $n}')
  [ "$S0" = "1" ] && OTHER=$k
done
if [ -n "$OTHER" ]; then
  OY=$(echo $YS | awk -v n="$OTHER" '{print $n}')
  tap "$WON" "$OY"; sleep 0.7
else
  tap "$WON" "$TY"; sleep 0.7
fi
shot "$WORK/_t2.png"
detect "$WORK/_t2.png"
echo "  复原后选中态: [$SELS]  (点击前是 [$SELS_ORIG])"

echo
echo "结论: 选项点击列 TAPX=$WON"
echo "      选项 y 由 pix.py opts 实时取得(每页可能不同, 不要写死)"
echo "后续脚本传参: --tapx $WON --marker $MARKER"
