#!/bin/bash
# answer-run.sh — 自校正作答遍: 逐页读"实际选中态" -> 与答案键比对 -> 只点需要改的
#
# 必须具备的两个不变量(否则会静默改错):
#   [1] 先清除多余项, 最后才设正确项。
#       单选题是 radio 语义: 点答案项会自动清掉旧项。若之后又按"旧快照"去点旧项,
#       会把刚设对的答案顶掉(实测踩过: 第26题被改成 D)。
#   [2] 无论本题是否点成功, 本题的翻页点击必点。
#       跳过翻页会让后续每一页都错位一格, 整卷报废。
#
# 用法: bash answer-run.sh --key key.txt --dir <collect目录> --tapx 250 \
#                          [--marker blue] [--settle 400] [--from 1] [--to 196] [--backward]
#
# ⚠ 运行前手机必须【正停在 --from 那一页】。
#   采集遍与作答遍结束后都停在【本次处理的最后一页】(不会多走一步) ——
#   反向跑就从"最后一页"起, 正向跑要先退回"第一页", 否则整卷错位一格。
#   实测踩过: 多退了一页, 于是 key 的第 3 行被套到第 2 页上, 报出一堆假的"修正".
source "$(dirname "$0")/lib.sh"
need_serial

KEY=""; DIR="$WORK/collect"; TAPX=250; MARKER=blue; SETTLE=400; FROM=1; TO=196; BACK=0
while [ $# -gt 0 ]; do
  case "$1" in
    --key) KEY=$2; shift 2;;
    --dir) DIR=$2; shift 2;;
    --tapx) TAPX=$2; shift 2;;
    --marker) MARKER=$2; shift 2;;
    --settle) SETTLE=$2; shift 2;;
    --from) FROM=$2; shift 2;;
    --to) TO=$2; shift 2;;
    --backward) BACK=1; shift 1;;
    *) shift;;
  esac
done
[ -n "$KEY" ] || { echo "需要 --key key.txt"; exit 1; }
IDX="$DIR/index.txt"
[ -f "$IDX" ] || { echo "缺少 $IDX, 先跑 collect-run.sh"; exit 1; }

if [ "$BACK" -eq 1 ]; then SEQ=$(seq "$FROM" -1 "$TO"); else SEQ=$(seq "$FROM" "$TO"); fi
FIX=0; OK=0
for i in $SEQ; do
  LINE=$(sed -n "${i}p" "$IDX")
  NAVY=$(printf '%s' "$LINE" | awk -F'|' '{print $3}' | tr -d ' ')
  WANT=$(awk -v q="$i" '$1==q{print $2}' "$KEY")
  shot "$WORK/_a.png"
  OUT=$(pix_opts "$WORK/_a.png" --marker "$MARKER")
  YS=$(field "$OUT" OPTS); SELS=$(field "$OUT" SEL)

  CLR=""; SET=""; CHG=""
  for L in A B C D E F G H; do
    N=$(( $(printf '%s' "$L" | od -An -tu1 | awk '{print $1}') - 64 ))
    Y=$(printf '%s' "$YS" | awk -v n="$N" '{print $n}')
    S=$(printf '%s' "$SELS" | awk -v n="$N" '{print $n}')
    [ -z "$Y" ] && continue
    if printf '%s' "$WANT" | grep -q "$L"; then
      [ "$S" = "1" ] || SET="$SET $L:$Y"
    else
      [ "$S" = "1" ] && CLR="$CLR $L:$Y"
    fi
  done

  # 先清除
  for it in $CLR; do
    L=${it%%:*}; Y=${it##*:}
    tap "$TAPX" "$Y"; sleep 0.45; CHG="$CHG-$L"
  done
  # 后设定
  for it in $SET; do
    L=${it%%:*}; Y=${it##*:}
    tap "$TAPX" "$Y"; sleep 0.45; CHG="$CHG+$L"
  done

  if [ -n "$CHG" ]; then FIX=$((FIX+1)); echo "  第$i页 改: $CHG (目标 $WANT)"; else OK=$((OK+1)); fi

  # [2] 翻页必点
  if [ "$i" -ne "$TO" ]; then
    if [ "$BACK" -eq 1 ]; then X=277; else X=1162; fi
    tap "$X" "$NAVY"
    sleep "$(awk -v m="$SETTLE" 'BEGIN{printf "%.3f", m/1000}')"
  fi
done
echo "=== 完成: 已正确 $OK 页, 修正 $FIX 页 ==="
echo "该脚本是幂等的: 状态已对就不点。再跑一遍应报 '修正 0' —— 这是收敛的证明。"
