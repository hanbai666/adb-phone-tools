# dsh-phone-preset

只做一件事：往 DSH 里插入一个 **「手机自动化模式」agent 预设**。

工具本体在旁边的 `dsh-phone-tools`（普通依赖）。两者分开是必须的：

- 一个包一旦被列进 `dsh.profile.bundles`，它的**主模块会被全局加载** ——
  如果 `dsh-phone-tools` 自己当 bundle，`phone_*` 工具就会出现在**所有**预设里，
  这正是要避免的。
- 所以：`dsh-phone-tools` 只作为依赖被预设引用；本包是个**空模块**，
  唯一的职责是用 `cordis.patch.yml` 把预设插进去。

## cordis.patch.yml 的关键写法

新增顶层条目必须用 `insert`，裸写 `- id: xxx` 会被**静默忽略**：

```yaml
- insert:
    - id: preset-phone
      name: '@deepseek-ai/dsh-agent-preset'
      config:
        id: phone
        order: 6
        name: 手机自动化模式
        description: ...
        plugins:
          - id: tool-phone
            name: dsh-phone-tools
```

## 验证

重启 DSH 后，`profiles/desktop/cordis.yml` 里应出现 `- id: preset-phone`，
且全文 `dsh-phone-tools` **只出现一次**（在预设内部）。实测：

```
1421:- id: preset-phone      ← 预设已插入
1593:        name: dsh-phone-tools   ← 全文唯一一处，在预设内
```
